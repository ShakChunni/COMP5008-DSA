# Author: F.M. Ashfaq
# Student ID: 23472297
# Date: 2026-10-25
# Purpose: Demonstrate farm hashing, collisions, searches, deletion and resizing.

import numpy as np
from services.DataLoader import ROOT, loadFarmRecords
from models.FarmRecord import FarmRecord
from module2_hash.DSAHashTable import DSAHashTable
from tests.TestHelpers import check, expectError


def runTests():
    records = loadFarmRecords(ROOT / "data/dataset.csv")
    table = DSAHashTable(53)
    farm_count = records.count()
    print(f"=== {farm_count} REAL FARM INSERTIONS WITH PROBING AND RESIZING ===")
    for record in records:
        table.insert(record, trace=True)
    check(f"{farm_count} farm records loaded", farm_count >= 40 and table.getCount() == farm_count)
    check("resized to prime capacity 107", table.getSize() == 107)
    for record in records:
        check("complete record retrieved " + record.farm_id, table.search(record.farm_id) is record)
    print("Complete successful search:", table.search(records.peekFirst().farm_id, trace=True))
    expectError("missing farm search", KeyError, lambda: table.search("zzzzz", trace=True))
    expectError("duplicate FarmID", ValueError, lambda: table.insert(records.peekFirst(), trace=True))
    before = table.getCount()
    table.delete(records.peekFirst().farm_id, trace=True)
    check("deletion changes count/load", table.getCount() == before - 1 and table.loadFactor() == (farm_count - 1) / 107)
    expectError("search after deletion", KeyError, lambda: table.search(records.peekFirst().farm_id, trace=True))
    expectError("repeat deletion", KeyError, lambda: table.delete(records.peekFirst().farm_id, trace=True))
    expectError("missing deletion", KeyError, lambda: table.delete("zzzzz", trace=True))
    table.insert(records.peekFirst(), trace=True)
    check("reinsertion after deletion", table.search(records.peekFirst().farm_id) is records.peekFirst())

    print("=== EXPLICIT REAL-ID COLLISION AND TOMBSTONE ===")
    collision_table = DSAHashTable(53)
    first = second = None
    for candidate in records:
        for other in records:
            if candidate is not other and collision_table.hash(candidate.farm_id) == collision_table.hash(other.farm_id):
                first = candidate
                second = other
                break
        if first is not None:
            break
    check("collision pair found in actual dataset", first is not None)
    print(f"Both {first.farm_id} and {second.farm_id} hash to {collision_table.hash(first.farm_id)}")
    collision_table.insert(first, trace=True)
    collision_table.insert(second, trace=True)
    collision_table.delete(first.farm_id, trace=True)
    check("search continues beyond tombstone", collision_table.search(second.farm_id, trace=True) is second)
    collision_table.insert(first, trace=True)
    check("tombstone reusable", collision_table.getCount() == 2)

    print("=== RECORD VALIDATION ===")
    valid = records.peekFirst()

    def makeRecord(farm_id=valid.farm_id, name=valid.name, lat=valid.latitude, lng=valid.longitude):
        return FarmRecord(farm_id, name, valid.species, lat, lng, valid.street_num,
                          valid.street, valid.suburb, valid.state, valid.postcode, valid.country)

    invalid_ids = np.empty(6, dtype=object)
    invalid_ids[0] = ""
    invalid_ids[1] = " bad"
    invalid_ids[2] = "bad-id"
    invalid_ids[3] = None
    invalid_ids[4] = 123
    invalid_ids[5] = "é123"
    for identifier in invalid_ids:
        expectError(f"invalid FarmID {identifier}", ValueError, lambda identifier=identifier: makeRecord(farm_id=identifier))
        expectError("invalid search ID", ValueError, lambda identifier=identifier: table.search(identifier))
    expectError("blank farm name", ValueError, lambda: makeRecord(name=" "))
    invalid_coordinates = np.empty(7, dtype=object)
    invalid_coordinates[0] = "bad"
    invalid_coordinates[1] = None
    invalid_coordinates[2] = True
    invalid_coordinates[3] = float("nan")
    invalid_coordinates[4] = float("inf")
    invalid_coordinates[5] = 91
    invalid_coordinates[6] = -91
    for value in invalid_coordinates:
        expectError(f"invalid latitude {value}", ValueError, lambda value=value: makeRecord(lat=value))
    invalid_coordinates[5] = 181
    invalid_coordinates[6] = -181
    for value in invalid_coordinates:
        expectError(f"invalid longitude {value}", ValueError, lambda value=value: makeRecord(lng=value))
    check("coordinate boundary values accepted", makeRecord(lat=90, lng=-180).latitude == 90)
    expectError("oversized coordinate integer", ValueError, lambda: makeRecord(lat=10 ** 1000))
    expectError("invalid table record", ValueError, lambda: table.insert("not a record"))
    print("HASH TESTS PASSED")


if __name__ == "__main__":
    runTests()
