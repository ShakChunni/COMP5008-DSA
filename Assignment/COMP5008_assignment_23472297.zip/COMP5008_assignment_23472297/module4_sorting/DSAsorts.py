# Author: F.M. Ashfaq
# Student ID: 23472297
# Date: 2026-10-25
# Purpose: Implement Merge Sort and Quick Sort by transportation time.

# Based on the sorting interfaces in my Practical 1; algorithms implemented here.
# Reference: Cormen et al., Introduction to Algorithms, 4th ed., 2022.

import numpy as np


def mergeSort(records):
    """Stable, top-down Merge Sort by transport time; modify the array in place."""
    temporary = np.empty(len(records), dtype=object)
    for index in range(len(records)):
        temporary[index] = None

    def recurse(left, right):
        if left < right:
            middle = (left + right) // 2
            recurse(left, middle)
            recurse(middle + 1, right)
            first = left
            second = middle + 1
            for target in range(left, right + 1):
                if (first <= middle and
                        (second > right or records[first].transport_time <= records[second].transport_time)):
                    temporary[target] = records[first]
                    first += 1
                else:
                    temporary[target] = records[second]
                    second += 1
            for index in range(left, right + 1):
                records[index] = temporary[index]

    recurse(0, len(records) - 1)
    return records


def quickSort(records):
    """Median-of-three pivot, Hoare partition; equal keys progress on both sides.

    Recurse on the smaller partition and loop over the larger one to bound the
    recursion stack by O(log n), even when partitions are unbalanced.
    """
    def median(first, middle, last):
        if first < middle:
            if middle < last:
                result = middle
            elif first < last:
                result = last
            else:
                result = first
        elif first < last:
            result = first
        elif middle < last:
            result = last
        else:
            result = middle
        return result

    def partition(left, right):
        pivot = median(records[left].transport_time,
                       records[(left + right) // 2].transport_time,
                       records[right].transport_time)
        first = left - 1
        second = right + 1
        crossed = False
        while not crossed:
            first += 1
            while records[first].transport_time < pivot:
                first += 1
            second -= 1
            while records[second].transport_time > pivot:
                second -= 1
            if first >= second:
                crossed = True
            else:
                temporary = records[first]
                records[first] = records[second]
                records[second] = temporary
        return second

    def recurse(left, right):
        while left < right:
            boundary = partition(left, right)
            if boundary - left < right - boundary:
                recurse(left, boundary)
                left = boundary + 1
            else:
                recurse(boundary + 1, right)
                right = boundary

    recurse(0, len(records) - 1)
    return records


def isSorted(records):
    ordered = True
    for index in range(1, len(records)):
        if records[index - 1].transport_time > records[index].transport_time:
            ordered = False
    return ordered
